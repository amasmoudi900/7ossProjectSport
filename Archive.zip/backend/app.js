// import express module
const express = require("express");
// import body-parser module
const bodyParser = require("body-parser");

// create express application
const app = express();

// Configuration
// Send JSON responses
app.use(bodyParser.json());
// Parse Request Objects
app.use(bodyParser.urlencoded({ extended: true }));

// Security configuration
app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, Accept, Content-Type, X-Requested-with, Authorization, expiresIn"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, DELETE, OPTIONS, PATCH, PUT"
  );
  next();
});

let matches = [
  { id: 1, scoreOne: 2, scoreTwo: 1, teamOne: "FCB", teamTwo: "RMD" },
  { id: 2, scoreOne: 1, scoreTwo: 1, teamOne: "JUV", teamTwo: "INT" },
  { id: 3, scoreOne: 3, scoreTwo: 0, teamOne: "CIT", teamTwo: "LIV" },
  { id: 4, scoreOne: 1, scoreTwo: 2, teamOne: "SEV", teamTwo: "ATM" },
  { id: 5, scoreOne: 2, scoreTwo: 2, teamOne: "PSG", teamTwo: "OM" },
];

let players = [
  { id: 1, name: "Messi", nbr: 10, position: "ATK", age: "36" },
  { id: 2, name: "Ronaldo", nbr: 7, position: "MID", age: "33" },
  { id: 3, name: "Bechir", nbr: 1, position: "GK", age: "37" },
  { id: 4, name: "Bechir", nbr: 1, position: "GK", age: "37" },
  { id: 5, name: "Bechir", nbr: 1, position: "GK", age: "37" },
  { id: 6, name: "Bechir", nbr: 1, position: "GK", age: "37" },
];
// Business Logic : Get All matches
// une fonction qui va s'exécuter automatiquement selon le Request:
// HTTP Method Get || Address: http://localhost:3000/matches
app.get("/matches", (req, res) => {
  console.log("Here into business logic : Get All matches ...");
  // Send Response : Array of matches  [{}, {}, {} ....]
  res.json({
    matchesKey: matches,
  });
});

// Business Logic : Get All Players
app.get("/players", (req, res) => {
  console.log("Here into get all players");
  res.json({
    playersKey: players,
  });
});

// Business Logic : Get match by ID
app.get("/matches/:id", (req, res) => {
  console.log("Here into get match by id");
  let findedMatch;
  let ID = req.params.id;
  console.log("Here ID from FE", ID);
  findedMatch = matches.find((obj) => {
    return obj.id == ID;
  });
  console.log("Here finded match", findedMatch);
  res.json({
    match: findedMatch,
  });
});

// Business Logic : Delete match by ID
app.delete("/matches/:id", (req, res) => {
  console.log("Here into delete match by id");
  let ID = req.params.id;
  let pos;
  console.log("Here id ", ID);
  for (let i = 0; i < matches.length; i++) {
    if (matches[i].id == ID) {
      pos = i;
      break;
    }
  }
  matches.splice(pos, 1);
  res.json({
    message: "Match is deleted",
  });
});
// Business Logic : Edit match by ID
// Business Logic : Add Match

// Business Logic : Get All players
// Business Logic : Get player by ID
// Business Logic : Delete player by ID
// Business Logic : Edit player by ID
// Business Logic : Add Player

// app is importable from another files
module.exports = app;
